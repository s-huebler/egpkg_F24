#' @importFrom Rcpp evalCpp
#' @useDynLib egpkg, .registration = TRUE
NULL
